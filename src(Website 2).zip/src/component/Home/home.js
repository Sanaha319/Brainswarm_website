import React from 'react'
import './home.css'
import img from '../../Images/body.png';
import { motion } from 'framer-motion';
const home = () => {


  return (
    <section id='home' className='home'>
      <div className='home__container'>
          <div className='home__left'>

              <div className='home__title'>
                <motion.h3>Welcome to the</motion.h3>
                <motion.h1 
                initial={{y: "2rem", opacity:0}} animate={{y: 0, opacity: 1}} transition={{duration: 5, type: 'spring'}}>
                  <span className='inv'>BrainSwarm Robotics Lab</span></motion.h1>
              </div>
              
              <div className='home__dis'>
                    <p className='para'>
                      BrainSwarm is a low-cost miniature robotic platform for educational
                      institutes to empower the youth with <b>high-tech skill development</b>.
                      lorem ipsum dolor sit amet consectetur adipisicing elit. Atque soluta hic
                      consequuntur eum repellendus ad. 
                      <br/>
                      <br/>
                    </p>
              </div>
          </div>

          <div className='home__right'>
              <motion.div initial={{x: "40rem", opacity:0}} animate={{x: 0, opacity: 1}} transition={{duration: 5, type: 'spring'}}
              className='image__container'>
                <img src={img} className='img' alt=''/>
              </motion.div>
          </div>
      </div>

    </section>
  )
}

export default home
