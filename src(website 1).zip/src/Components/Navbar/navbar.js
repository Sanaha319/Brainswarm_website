import React, { useState } from "react";
import './navbar.css';
import { AiFillCloseCircle } from 'react-icons/ai';
import { TbGridDots } from 'react-icons/tb';
import web from "../../Assets/Images/logo.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSun, faSnowflake, faBook, faUser, faCamera, faNewspaper, faHome, faRobot, faPhone, faPager, faBlog } from '@fortawesome/free-solid-svg-icons';


const Navbar = () => {
    const [active, setActive] = useState(false);
    const [educatorDropdown, setEducatorDropdown] = useState(false);
    const [blogDropdown, setBlogDropdown] = useState(false);
    const [learnDropdown, setLearnDropdown] = useState(false);

    // Function to toggle navBar
    const showNav = () => {
        setActive(!active);
    }

    // Function to toggle Educator dropdown
    const toggleEducatorDropdown = () => {
        setEducatorDropdown(!educatorDropdown);
    }

    // Function to toggle Blog dropdown
    const toggleBlogDropdown = () => {
        setBlogDropdown(!blogDropdown);
    }

    // Function to toggle Learn dropdown
    const toggleLearnDropdown = () => {
        setLearnDropdown(!learnDropdown);
    }

    // Function to prevent default behavior of anchor links
    const preventDefault = (e) => {
        e.preventDefault();
    }

    return (
        <section className="navBarSection">
            <header className="header flex">
                <div className="logoDiv">
                    <a href="#" className="logo flex">
                        <div className="image">
                            <img src={web} alt="" />
                        </div>
                        <div className="txt">
                            <h2>BrainSwarm</h2>
                        </div>
                    </a>
                </div>

                <div className={`navBar ${active ? 'activeNavbar' : ''}`}>
                    <ul className="navLists flex">
                        <li className="navItem">
                            <a href="./" className="navLink" onClick={preventDefault}> <FontAwesomeIcon icon={faHome} />Home</a>
                        </li>

                    <li className="navItem">
                    <div className="navLink"onClick={toggleLearnDropdown}> <FontAwesomeIcon icon={faBook} />Learn</div>
                    {learnDropdown && (
                    <ul className="dropdown-content">
                        <li>
                            <div onClick={toggleLearnDropdown}>
                                <FontAwesomeIcon icon={faRobot} /> Bots
                            </div>
                        </li>
                        <li>
                            <div onClick={toggleLearnDropdown}>
                                <FontAwesomeIcon icon={faCamera} /> Drones
                            </div>
                        </li>
                    </ul>
                )}
                </li>

                <li className="navItem">
                        <div className="navLink"onClick={toggleEducatorDropdown}><FontAwesomeIcon icon={faRobot} />Educators</div>
                        {educatorDropdown && (
                            <ul className="dropdown-content">
                                <li>
                                    <div onClick={toggleEducatorDropdown}>
                                        <FontAwesomeIcon icon={faSun} /> Summer Bootcamps
                                    </div>
                                </li>
                                <li>
                                    <div onClick={toggleEducatorDropdown}>
                                        <FontAwesomeIcon icon={faSnowflake} /> Winter Bootcamps
                                    </div>
                                </li>
                                <li>
                                    <div onClick={toggleEducatorDropdown}>
                                        <FontAwesomeIcon icon={faBook} /> Tutorials
                                    </div>
                                </li>
                            </ul>
                        )}
                    </li>

                    <li className="navItem">
                        <div className="navLink"onClick={toggleBlogDropdown}><FontAwesomeIcon icon={faBlog} />Blog</div>
                        {blogDropdown && (
                            <ul className="dropdown-content">
                                <li>
                                    <div onClick={toggleBlogDropdown}>
                                        <FontAwesomeIcon icon={faNewspaper} /> Newsletter
                                    </div>
                                </li>
                            </ul>
                        )}
                    </li>


                                    <li className="navItem">
                                        <div className="navLink"><FontAwesomeIcon icon={faPager} />Portfolio</div>
                                    </li>

                        <li className="navItem">
                        <button className="btn">
                        <a href="../Learn"><FontAwesomeIcon icon={faPhone} />Conatact Us</a>
                        </button>
                        </li>                

                    </ul>

                    <div onClick={showNav} className="closeNavbar">
                        <AiFillCloseCircle className="icon" />
                    </div>
                </div>
                <div onClick={showNav} className="toggleNavbar">
                    <TbGridDots className="icon" />
                </div>

            </header>
        </section>
    )
}

export default Navbar;
