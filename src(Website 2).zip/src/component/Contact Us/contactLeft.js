import React from 'react'
import contact from '../../Images/contactImg.png';
import {FaFacebookF, FaTwitter, FaLinkedinIn} from 'react-icons/fa';
import './contact.css';
const ContactLeft = () => {
  return (
    <div className='sliding1'>
        <img className='img' src={contact} alt='' />

        <div className='cont_pic'>
            <h3 className='Rlab'>Swarm Robotics Lab</h3>
            <p className='disc'>Located in UET Taxila CS Department</p>
            <p className='disc_details'>
                lorem ipsum dolor sit amet consectetur adipisicing elit. Atque soluta hic consequuntur eum 
                repellendus ad. Facilis ipsam autem cumque, accusantium dicta odio.
            </p>
            <p className='phone'>Phone: <span>+92 300 1234567</span></p>
            <p className='email'>Email: {" "} <span>info@gmail.com</span></p>
        </div>

        <div className='handle_account'> 
            <h2 className='left-div'>Find us in</h2>
            <div className='social__media'>
                <span className='icons'><FaFacebookF/></span>
                <span className='icons'><FaTwitter/></span>
                <span className='icons'><FaLinkedinIn/></span>
            </div>
        </div>
    </div>
  )
}

export default ContactLeft
