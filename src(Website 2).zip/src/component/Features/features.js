import React from 'react';
import {MdCastForEducation} from 'react-icons/md';
import {GiRobotGrab} from 'react-icons/gi';
import {LiaConnectdevelop} from 'react-icons/lia';
import './features.css';
import Body from '../Layout/body';
import Card from './card';

const features = () => {
  return (
    <section id='service' className='service'>
      <div className='body'>
        <Body title="Services" des="What We Do"/>
      </div>
      

      <div className='card'>
        <Card 
          title="Learning About Robots"
          des="lorem ipsum dolor sit amet consectetur adipisicing elit. Atque soluta hic consequuntur eum 
          repellendus ad."
          icons={<GiRobotGrab/>}/>

        <Card
          title="Educating Students"
          des="lorem ipsum dolor sit amet consectetur adipisicing elit. Atque soluta hic consequuntur eum 
          repellendus ad."
          icons={<MdCastForEducation/>}/>
        <Card
          title="Developing Robots"
          des="lorem ipsum dolor sit amet consectetur adipisicing elit. Atque soluta hic consequuntur eum 
          repellendus ad."
          icons={<LiaConnectdevelop/>}/>
      </div>
    </section>
  )
}

export default features
