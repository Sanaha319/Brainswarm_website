import React,{useEffect} from 'react';
import "./products.css";
import Aos from 'aos';
import 'aos/dist/aos.css';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import img1 from "../../Assets/Images/pimage1.jpg"
import img2 from "../../Assets/Images/pimage2.jpg"
import img3 from "../../Assets/Images/pimage3.jpg"
import img4 from "../../Assets/Images/pimage4.jpg"
import img5 from "../../Assets/Images/pimage5.jpg"
import img6 from "../../Assets/Images/pimage6.jpg"

const Products = () => {
    useEffect(()=>{
        Aos.init({duration:3000})
    }, [])

    return (
        <div>
          <Carousel infiniteLoop autoPlay>
          <div data-aos="flip-right"  className="image">
                <img src={img1} alt="Product Image 1" />
            </div>
            <div data-aos="flip-right" className='image'>
                <img src={img2} alt="Product Image 2" />
            </div>
            <div data-aos="flip-right" className='image'>
                <img src={img3} alt="Product Image 3" />
            </div>
            <div data-aos="flip-right" className='image'>
                <img src={img4} alt="Product Image 4" />
            </div>
            <div data-aos="flip-right" className='image'>
                <img src={img5} alt="Product Image 5" />
            </div>
            <div data-aos="flip-right" className='image'>
                <img src={img6} alt="Product Image 6" />
            </div>
          </Carousel>
        </div>
      );
    };
  
  export default Products;
