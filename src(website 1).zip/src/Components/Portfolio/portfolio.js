import React from "react";
import { useState, useEffect } from 'react';
import './portfolio.css';
import { useSpring,animated } from "react-spring";


function Number ({ n }) {
    const {number} = useSpring({
        from: {number: 0},
        number: n,
        delay: 200,
        config: {mass:1,tension:20,friction:10 },

    });
    useEffect(() => {
        // Start the animation when the component mounts
        const interval = setInterval(() => {
          number.start({ number: n }); // Set the final number you want to display
        }, 1000); // Change this to control the animation speed
    
        // Stop the animation when the component unmounts
        return () => clearInterval(interval);
      }, []);
    return (
        <animated.div>
          {number.to((n) => Math.round(n))}
        </animated.div>
      );
}


const Portfolio = () => {

    const [count, setCounter] = useState('count')
    // function to toggle navBar
    const runCounter = () => {
        setCounter('count counterUp')
    }

    return(

        <section class="projectwork">
            <div className="projectDiv">
                <div class="Container" data-aos="flip-right">
                    <h1 class="text-center"  data-aos="fade-down">MORE THAN 2,000 <span> PORTFOLIOS</span> CREATED</h1>
                </div>

                <div class="containers flex">
                    <div className="divItems" data-aos="slide-right">
                        <h1>  < Number n={1500} /> </h1>
                        <span className="spandiv">Portfolios</span>
                    </div>

                    <div className="divItems" data-aos="slide-up">
                        <h1>
                            < Number n={2500} /> 
                        </h1>
                        <span className="spandiv">Robots</span>
                    </div>

                    <div className="divItems" data-aos="slide-down">
                        <h1>  < Number n={700} /></h1>
                        <span className="spandiv">Certificates</span>
                    </div>

                    <div className="divItems" data-aos="slide-left">
                        <h1> < Number n={500} /></h1>
                        <span className="spandiv">Products</span>
                    </div>
                </div>
            </div>
	    </section>
    )
}

export default Portfolio;