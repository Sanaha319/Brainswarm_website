import React from "react";
import "./contact.css";
import img from "../../Assets/Images/contact.png";
import { FiSend } from "react-icons/fi";

const About = () => {
    return(
        <section className="contact flex section">
            <div className="contactDiv flex">
                <div data-aos="flip-right">
                    <img  className="contactimg" src={img} alt=""/>
                </div>

                <div className="text">
                    <div className="text1">
                        <h3 data-aos="flip-down">Contact Us</h3>
                        <h2 data-aos="slide-left">Be Well, Stay Calm And <br/><span>Keep In Touch</span> </h2>

                        
                    </div>
                    <div className="contactCard grid">
                        <div className="box">
                            <div className="inputDiv grid">
                                <input data-aos="fade-right" className="input" type="text" placeholder="Enter First Name" />
                                <input data-aos="fade-left" className="input" type="text" placeholder="Enter Last Name" />
                                <input data-aos="fade-right" className="input" type="text" placeholder="Enter Email Address" />
                                <input data-aos="fade-left" className="input" type="text" placeholder="Enter Phone Number" />
                            </div>
                            <div className="textbox">
                                <textarea data-aos="fade-up" placeholder="Message" required></textarea>
                            </div>

                            <a href="../Home"><button data-aos="fade-left" className="btn flex" type="submit">
                                    SEND<FiSend className='icons'/>
                            </button>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
            
        </section>
    )
}

export default About;
