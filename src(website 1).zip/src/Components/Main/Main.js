import React, {useEffect} from "react";
import './main.css';
import Aos from 'aos';
import 'aos/dist/aos.css';
import img from "../../Assets/Images/body.png";

const Main = () => {
    
    useEffect(()=>{
        Aos.init({duration:2000})
    }, [])

    return (
        <section className="main flex section">            
            <div data-aos="flip-right"  className="secTitle">
                <img src={img}/>
            </div>

            <div className="body container">
                <div data-aos="fade-right" className="title grid">
                    <h1 className="h1">EMPOWERING MINDS FOR <span>INNOVATION</span>​</h1>
                </div>
                <div className="secContent grid" data-aos="fade-left" data-aos-duration="5000">
                    <p>
                        BrainSwarm is a low-cost miniature robotic platform for educational institutes to empower the youth with <b>high-tech skill development</b>.
                        <br/>
                        <br/>
                        Brainswarm believes in providing experiences that support building understanding, critical thinking, problem solving via interdisciplinary learning environment through <b>STREAM </b> <i>( Science, Technology, Religion, Engineering, Art, Mathematics )</i>
                    </p>
                    <button className="btn">
                        <a href="../Learn">Start Your Journey</a>
                    </button>
                </div>
            </div>

        </section>
    )
}

export default Main