import React from "react";
import "./App.css"
import Navbar from "./component/Navbar/navbar";
import Home from './component/Home/home';
import Feature from './component/Features/features';
import Testimonial from './component/Testimonial/testimonial';
import Contact from './component/Contact Us/contact';
import Footer from './component/Footer/footer';
const App = () => {
  return(
    <div className="settings">
        <Navbar/>
      <div className="navbar">
        <Home/>
        <Feature/>
        <Testimonial/>
        <Contact/>
        <Footer/>
      </div>

    </div>
  )
}

export default App