import React, {useEffect} from "react";
import './footer.css';
import {GrMap, GrWebcam, GrChat} from 'react-icons/gr';
import {HiOutlineSearch} from 'react-icons/hi';
import { FiChevronRight, FiSend } from "react-icons/fi";
import {MdOutlineTravelExplore} from "react-icons/md";
import {AiOutlineTwitter} from "react-icons/ai";
import {AiFillYoutube} from "react-icons/ai";
import {AiFillInstagram} from "react-icons/ai";
import {AiFillLinkedin} from "react-icons/ai";
import {FiFacebook} from "react-icons/fi";

import Aos from 'aos';
import 'aos/dist/aos.css';

const Footer = () => {

    useEffect(()=>{
        Aos.init({duration:2000})
    }, [])

    return (
        <section className="footer">
            <div className="secContent container">
                <div className="contactDiv flex">
                    <div data-aos="flip-up" className="text">
                        <small className="small">KEEP IN TOUCH</small>
                        <h2>Feel free to ask over any query</h2>
                    </div>

                    <div className="inputDiv flex">
                        <input data-aos="fade-right" className="input" type="text" placeholder="Enter Email Address" />
                        <button data-aos="fade-left" className="btn flex" type="submit">
                            SEND<FiSend className='icon'/>
                        </button>
                    </div>
                </div>

                <div className="footerCard flex">
                    <div className="footerIntro flex">
                        <div className="logoDiv" data-aos="flip-left">
                            <a href="#" className="logo flex"> 
                                <MdOutlineTravelExplore className="icon"/> 
                                <h3 data-aos="fade-right">BrainSwarm Robotic Labs</h3>
                            </a>
                        </div>

                        <div data-aos="slide-up" className="footerPragraph">
                            BrainSwarm is located in a rapidly changing and fiercely competitive global environment, Pakistan has to make bold strategic choices in order to achieve sustainable growth in the manufacturing sector. 
                        </div>

                    </div>

                    <div className="footerLinks grid">
                        <div data-aos="fade-down" data-aos-duration="3000" className="linkgroup">
                            <span className="groupTitle">
                                BrainSwarm
                            </span>

                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Home
                            </li>
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Learn
                            </li>
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Educators
                            </li>
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Products
                            </li>
                            
                        </div>

                        <div data-aos="fade-up" data-aos-duration="4000" className="linkgroup">
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Blog
                            </li>
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                About Us
                            </li>
                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Testimonies
                            </li>

                            <li className="footerList flex">
                                <FiChevronRight className="icons"/>
                                Contact Us
                            </li>


                        </div>

                        
                    </div>

                    <div className="officeinfo">
                            <div className="logoDiv" data-aos="flip-left">
                                <a href="#" className="logo flex"> 
                                    <HiOutlineSearch className="icon"/> 
                                    <h3 data-aos="fade-right">Information</h3>
                                </a>
                                
                                <div className="block flex">
                                    <div className="info grid">
                                        <div className="boxitems flex">
                                            <div className="icons">
                                                <GrMap className="icons"/>
                                            </div>
                                            <div className="info">
                                                <p className="para">Swarm Robotics Lab, CE Department, 1st Floor, UET Taxila, Pakistan</p>
                                            </div>
                                        </div>
                                        <div className="boxitems flex">
                                            <div className="icons">
                                                <GrChat className="icons"/>
                                            </div>
                                            <div className="info">
                                                <a className="para" href="+92 (312) 5255 123">+92 (312) 5255 123</a>
                                            </div>
                                        </div>
                                        <div className="boxitems flex">
                                            <div className="icons">
                                                <HiOutlineSearch className="icons"/>
                                            </div>
                                            <div className="info">
                                                <a className="para" href="info@brainswarms.com">info@brainswarms.com</a>
                                            </div>
                                        </div>
                                        <div className="boxitems flex">
                                            <div className="icons">
                                                <GrWebcam className="icons"/>
                                            </div>
                                            <div className="info">
                                                <a className="para" href="https://brainswarms.com">brainswarms.com</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                
                            </div>
                    </div>
                    
                    <div data-aos="fade-left" data-aos-duration="4000" className="media">
                            <div className="footerSocial grid">
                                <a href="#"><AiOutlineTwitter className="icon"/></a>
                                <a href="https://www.linkedin.com/company/brainswarm?originalSubdomain=pk"><AiFillLinkedin className="icon"/></a>
                                <a href="#"><AiFillYoutube className="icon"/></a>
                                <a href="#"><AiFillInstagram className="icon"/></a>
                                <a href="https://www.facebook.com/BrainSwarming/">< FiFacebook className="icon"/></a>
                            </div>
                        </div>

                    <div className="footerDiv flex">
                        <small className="copyrights">BEST LEARNING FACILITIES</small>
                        <small className="copyrights">@COPYRIGHTS RESERVED - BRAINSWARM 2023</small>
                    </div>
                    
                </div>

                    
            </div>
        </section>
    )
}

export default Footer