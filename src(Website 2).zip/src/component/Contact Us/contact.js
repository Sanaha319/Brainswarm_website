import React from 'react';
import Title from '../Layout/body';
import './contact.css';
import ContactLeft from './contactLeft';
import ContactRight from './ContactRight';

const Contact = () => {
  return (
    <section className='contact'>
    <div className='title'>
        <Title title="CONTACT" des="Contact With Us"/>
    </div>

    <div className='slides'>
            <div className='slideshow'>
                <ContactLeft />
                < ContactRight />
            </div>
    
    </div>

    </section>
  )
}

export default Contact;
