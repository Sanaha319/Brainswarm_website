import React, { useState } from 'react';
import './contact.css';

const ContactRight = () => {

    const [username, setUserName] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [email, setEmail] = useState("");
    const [subject, setSubject] = useState("");
    const [message, setMessage] = useState("");
    const [errMsg, setErrMsg] = useState("");
    const [successMsg, setSuccessMsg] = useState("");

    //email validation starts
    const emailValidation = () => {
        return String(email).toLocaleLowerCase().match(
            /^\w+([-]?\w+)*@\w+([-]?\w+)*(\.\w{2,3})+$/);
    }

    //email validation ends
    const handleSend = (e) => {
        e.preventDefault()
        if (username === ""){
            setErrMsg('Username is required!');
        }else if (phoneNumber === ""){
            setErrMsg('Phone Number is required!')
        }else if (email === ""){
            setErrMsg('Email is required!')
        }else if (!emailValidation(email)){
            setErrMsg('Give a valid email')
        }else if (message === ""){
            setErrMsg('Message is required!')
        }else if (subject === ""){
            setErrMsg('Subject is required!')
        }else{
            setSuccessMsg(`Thank you dear ${username}, Your message has been sent successfully!`)
            setErrMsg(" ")
            setUserName("")
            setPhoneNumber("")
            setEmail("")
            setSubject("")
            setMessage("")
            console.log(username, phoneNumber, email, subject, message)
        }

    }
  return (
    <div className='sliding2'>
        <form className='form'>
            {
                errMsg && <p className='errorMsg'>{errMsg}</p>
            }

            {
                successMsg && <p className='successMsg'>{successMsg}</p>
            }
            <div className='form-right'>
                <div className='form-right-name'>
                    <p className='form_name'>Your Name</p>
                    <input onChange={(e) => setUserName(e.target.value)} 
                    value={username} className='form_dis 'type='text' />
                </div>

                <div className='form-right-phone'>
                    <p className='form_name'>phone number</p>
                    <input onChange={(e) => setPhoneNumber(e.target.value)} 
                    value={phoneNumber} className='form_dis' type='text' />
                </div>
            </div>
                
            <div className='form-right-email'>
                <p className='form_name'>email</p>
                <input onChange={(e) => setEmail(e.target.value)} 
                    value={email} className='form_dis' type='email' />
            </div>

            <div className='form-right-sub'>
                <p className='form_name'>subject</p>
                <input onChange={(e) => setSubject(e.target.value)} 
                    value={subject} className='form_dis' type='text' />
            </div>

            <div className='form-right-msg'>
                <p className='form_name'>message</p>
                <textarea onChange={(e) => setMessage(e.target.value)} 
                    value={message} className='form_des' cols="30" rows="8" />
            </div>

            <div className='form-right-btn'>
                <button onClick={handleSend} className='form_btn'>send message</button>
            </div>
            {
                errMsg && <p className='errorMsg'>{errMsg}</p>
            }

            {
                successMsg && <p className='successMsg'>{successMsg}</p>
            }
        </form>
    </div>
  )
}

export default ContactRight
