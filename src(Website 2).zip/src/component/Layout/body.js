import React from 'react'
import '../Features/features.css';

const body = ({title, des}) => {
    return (
        <div className='feature'>
          <h3 className='heading'>{title}</h3>
          <h1 className='showcase'>{des}</h1>
        </div>
      )
}

export default body;
