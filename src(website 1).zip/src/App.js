import React from "react";
import "./App.css"
import Navbar from "./Components/Navbar/navbar";
import Main from "./Components/Main/Main";
import Footer from "./Components/Footer/Footer";
import About from "./Components/About Us/about";
import Contact from "./Components/Contact Us/contact";
import Portfolio from "./Components/Portfolio/portfolio";
import Products from "./Components/Products/products";

const App = () => {
  return(
    <>
      <Navbar/>,
      <Main/>,
      <Portfolio/>,
      <Products/>,
      <About/>,
      <Contact/>,
      <Footer/>
    </>
  )
}

export default App