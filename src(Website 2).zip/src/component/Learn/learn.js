import React,{useState} from 'react'
import './navbar.css';
import { Link } from 'react-scroll';
import web from '../../Images/logo.png';


const Navbar = () => {
  const [active, setActive] = useState(false);
    const [educatorDropdown, setEducatorDropdown] = useState(false);
    const [blogDropdown, setBlogDropdown] = useState(false);
    const [learnDropdown, setLearnDropdown] = useState(false);

    // Function to toggle navBar
    const showNav = () => {
        setActive(!active);
    }

    // Function to toggle Educator dropdown
    const toggleEducatorDropdown = () => {
        setEducatorDropdown(!educatorDropdown);
    }

    // Function to toggle Blog dropdown
    const toggleBlogDropdown = () => {
        setBlogDropdown(!blogDropdown);
    }

    // Function to toggle Learn dropdown
    const toggleLearnDropdown = () => {
        setLearnDropdown(!learnDropdown);
    }

    // Function to prevent default behavior of anchor links
    const preventDefault = (e) => {
        e.preventDefault();
    }

  return (
    <div className='navBar'>
      <div className='logo'>
        
        <div className='image'>
            <img src={web} alt='logo'/>
        </div>
      </div>

       <div className={`navBar ${active ? 'activeNavbar' : ''}`}>
                    <ul className="navLists flex">
                        <li className="navItem">
                            <a href="./" className="navLink" onClick={preventDefault}>Home</a>
                        </li>

                        <li className="navItem">
                            <div className="navLink" onClick={toggleLearnDropdown}>Learn</div>
                            {learnDropdown && (
                                <ul className="dropdown-content">
                                    <li>
                                        <div onClick={toggleLearnDropdown}>
                                            Bots
                                        </div>
                                    </li>
                                    <li>
                                        <div onClick={toggleLearnDropdown}>
                                            Drones
                                        </div>
                                    </li>
                                </ul>
                            )}
                        </li>

                        <li className="navItem">
                            <div className="navLink" onClick={toggleEducatorDropdown}>Educators</div>
                            {educatorDropdown && (
                                <ul className="dropdown-content">
                                    <li>
                                        <div onClick={toggleEducatorDropdown}>
                                            Summer Bootcamps
                                        </div>
                                    </li>
                                    <li>
                                        <div onClick={toggleEducatorDropdown}>
                                            Winter Bootcamps
                                        </div>
                                    </li>
                                    <li>
                                        <div onClick={toggleEducatorDropdown}>
                                            Tutorials
                                        </div>
                                    </li>
                                </ul>
                            )}
                        </li>

                        <li className="navItem">
                            <div className="navLink" onClick={toggleBlogDropdown}>Blog</div>
                            {blogDropdown && (
                                <ul className="dropdown-content">
                                    <li>
                                        <div onClick={toggleBlogDropdown}>
                                            Newsletter
                                        </div>
                                    </li>
                                </ul>
                            )}
                        </li>

                        <li className="navItem">
                            <div className="navLink">Portfolio</div>
                        </li>

                        <li className="navItem">
                            <button className="btn">
                                <a href="../Learn">Contact Us</a>
                            </button>
                        </li>
                    </ul>

                    <div onClick={showNav} className="closeNavbar">
                    </div>
                </div>
                <div onClick={showNav} className="toggleNavbar">
                    
                </div>
    </div>
  )
}

export default Navbar
