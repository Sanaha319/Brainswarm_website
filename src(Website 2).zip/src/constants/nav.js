export const navData = [
    {
        _id: 1001,
        title: "Home",
        link: "home"
    },
    {
        _id: 1002,
        title: "Learn",
        link: "learn",
        subItems: [
            {
                _id: 2001,
                title: "Bots",
                link: "bots"
            },
            {
                _id: 2002,
                title: "Drones",
                link: "drones"
            },
        ],
    },
    {
        _id: 1003,
        title: "Educators",
        link: "educators",
        subItems: [
            {
                _id: 3001,
                title: "Summer Bootcamps",
                link: "summer-bootcamps"
            },
            {
                _id: 3002,
                title: "Winter Bootcamps",
                link: "winter-bootcamps"
            },
            {
                _id: 3003,
                title: "Tutorials",
                link: "tutorials"
            },
        ],
    },
    {
        _id: 1004,
        title: "Blog",
        link: "blog",
        subItems: [
            {
                _id: 4001,
                title: "Newsletter",
                link: "newsletter"
            },
        ],
    },
    {
        _id: 1005,
        title: "Portfolio",
        link: "portfolio"
    },
    {
        _id: 1006,
        title: "Contact Us",
        link: "contact-us"
    },
    {
        _id: 1007,
        title: "Services",
        link: "services"
    },
];
