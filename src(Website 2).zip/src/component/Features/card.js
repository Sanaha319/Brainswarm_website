import React from 'react'
import './features.css';
import {HiArrowRight} from 'react-icons/hi';
const card = ({title, des, icons}) => {
  return (
        <div className="boxes">
          <div className='card__content'>
            <div className='card__details'>

              <div>
                <span className='icon'>{icons}</span>
              </div>

              <div className='card__body'>
                <h2 className='title'>{title}</h2>
                <p className='content'>{des}</p>
                <span className='react-icon'><HiArrowRight/></span>
              </div>

            </div>
          </div>
        </div>
  )
}

export default card
