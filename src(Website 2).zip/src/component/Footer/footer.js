import React from 'react'
import './footer.css';
import web from '../../Images/logo.png';
import {FaFacebookF, FaTwitter, FaLinkedinIn} from 'react-icons/fa';
const Footer = () => {
  return (
    <div className='footer'>
      <div className='f1'>
        <img className='logo' src={web} alt='' />
        <div className='social__media'>
                <span className='icons'><FaFacebookF/></span>
                <span className='icons'><FaTwitter/></span>
                <span className='icons'><FaLinkedinIn/></span>
        </div>
      </div>

      <div className='f2'>
        <h3 className='links'>Quick Links</h3>
        <ul className='link1'>
          <li><span className='letter-effect'>About</span></li>
          <li><span className='letter-effect'>Serices</span></li>
          <li><span className='letter-effect'>Blog</span></li>
          <li><span className='letter-effect'>Contact</span></li>
        </ul>
      </div>

      <div className='f3'>
      <h3 className='links'>Resources</h3>
        <ul className='link1'>
          <li><span className='letter-effect'>Authentication</span></li>
          <li><span className='letter-effect'>System Status</span></li>
          <li><span className='letter-effect'>Terms of Services</span></li>
          <li><span className='letter-effect'>Open Source</span></li>
        </ul>
      </div>

      <div className='f4'>
      <h3 className='links'>Developers</h3>
        <ul className='link1'>
          <li><span className='letter-effect'>Documentation</span></li>
          <li><span className='letter-effect'>Authentication</span></li>
          <li><span className='letter-effect'>API Reference</span></li>
          <li><span className='letter-effect'>Support</span></li>
        </ul>
      </div>
    </div>
  )
}

export default Footer
