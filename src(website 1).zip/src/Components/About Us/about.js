import React from "react";
import "./about.css";
import img from "../../Assets/Images/about.png";
import img1 from "../../Assets/Images/smart.png";
import img2 from "../../Assets/Images/experts.png";

const About = () => {
    return(
        <section className="about flex section">
            <div className="aboutDiv flex">
                <div className="text">
                    <div className="text1">
                        <h3 data-aos="slide-down">About Us</h3>
                        <h2 data-aos="slide-left">Empowering <span>People</span> By Keeping Them Well</h2>

                        <p className="para" data-aos="fade-right">Brain Swarm Robotic Lab is working to empower the young students in the field of robotics.</p>
                    </div>
                    <div className="work grid">
                        <div className="workitem flex">
                            <img className="aboutimage" src={img1} alt=""/>
                            <div >
                                <h3 className="heading" data-aos="slide-down">Smart Solutions</h3>
                                <p className="para" data-aos="flip-left">
                                    We are providing the smart online and physical courses to young students<br/> including handson practices.
                                </p>
                            </div>
                        </div>
                        <div className="workitem flex">
                            <img className="aboutimage" src={img2} alt=""/>
                            <div >
                                <h3 className="heading"  data-aos="slide-down">Certified Experts</h3>
                                <p className="para" data-aos="flip-left">
                                    We have highly qualified experts with vast domain knowledge to help our <br/> youth to learn, grow and explore.
                                </p>
                            </div>
                        </div>
                    </div>
                    

                </div>

                <div data-aos="flip-right" className="img">
                    <img  className="aboutimg" src={img} alt=""/>
                </div>
            </div>
            
        </section>
    )
}

export default About;