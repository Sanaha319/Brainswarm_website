import React, { useState } from 'react'
import Title from '../Layout/body';
import './testimonial.css';
import Slider from "react-slick";
import {RiStarFill} from 'react-icons/ri';
import {HiArrowRight, HiArrowLeft} from 'react-icons/hi';
import person1 from '../../Images/person4.jpeg';
import quote from '../../Images/quote.png'; 
import person2 from '../../Images/person2.jpeg';
import person3 from '../../Images/person3.jpeg';

function SampleNextArrow(props) {
    const {onClick } = props;
    return (
      <div
        className="next_arrow"  
        onClick={onClick}
      ><HiArrowRight/></div>
    );
  }

function SamplePrevArrow(props) {
    const {onClick } = props;
    return (
        <div
            className="w-14 h-12 bg-[#0c1821] hover:bg-black duration-300 rounded-md text-2xl text-gray-4 flex
            justify-center items-center absolute top-0 right-20 shadow-shadowOne cursor-pointer z-10"
            onClick={onClick}
        ><HiArrowLeft/></div>
    );
}
    
const Testimonial = () => {
    const [dotActive, setDotActive] = useState(0);
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1, 
        nextArrow:<SampleNextArrow/>,
        prevArrow:<SamplePrevArrow/>,

        beforeChange : (prev, next) => {
            setDotActive(next);
        },

        appendDots: (dots) => (
            <div
              style={{
                borderRadius: "10px",
                padding: "10px"
              }}
            >
              <ul 
              style={{ 
                display: "flex",
                gap: "15px",
                justifyContent: "center",
                marginTop:"20px"
              }}
              > {" "}
              {dots} {" "}
              </ul>
            </div>
          ),
          customPaging: (i) => (
            <div
              style={
                i === dotActive?{
                        width: "12px",
                        height: "12px",
                        color: "blue",
                        background: "#ff104f",
                        borderRadius: "50%",
                        cursor: "pointer"
                }:{
                        width: "12px",
                        height: "12px",
                        color: "blue",
                        background: "gray",
                        borderRadius: "50%",
                        cursor: "pointer"
                }
              }
            >
            </div>
          )    
      };

  return (
    <section className='testimonial'>
        <div className='title'>
            <Title title="What Others Say" des="Testimonials"/>
        </div>
        <div className='slider'>
        <Slider {...settings}>

          <div className='slides'>
            <div className='slideshow'>
                <div className='sliding1'>
                    <img className='img1' src={person1} alt='' />
                    <div>
                        <p className='img_title'>TRAINEE</p>
                        <h3 className='img_name'>Ashal Khan</h3>
                        <p className='img_des'>Student</p>
                    </div>
                </div>
                <div className='sliding2'>
                    <img className='img2' src={quote} alt='' />
                    <div className='img2_body'>
                         <div className='testi'>
                            <div>
                                <h3 className='img2_parent'>Parent Ashal</h3>
                                <p className='img2_comments'>Let's see what Ashal parents said about us</p>
                            </div>

                            <div className='rating'>
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                            </div>
                         </div>

                         <div>
                            <p className='img2_content'>This course was incredible enriching experience. The instructors were very supportive.
                                Thank you for such a valuable learning opportunity for the kids.
                                Lorem ipsum neccesioutos nihil perspective repellate? isit
                            </p>
                         </div>
                    </div>
                </div>
            </div>
          </div>

          <div className='slides'>
            <div className='slideshow'>
                <div className='sliding1'>
                    <img className='img1' src={person2} alt='' />
                    <div>
                        <p className='img_title'>TRAINEE</p>
                        <h3 className='img_name'>Maryum</h3>
                        <p className='img_des'>Student</p>
                    </div>
                </div>
                <div className='sliding2'>
                    <img className='img2' src={quote} alt='' />
                    <div className='img2_body'>
                         <div className='testi'>
                            <div>
                                <h3 className='img2_parent'>Parent Maryum</h3>
                                <p className='img2_comments'>Let's see what Maryum parents said about us</p>
                            </div>

                            <div className='rating'>
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                            </div>
                         </div>

                         <div>
                            <p className='img2_content'>This course was incredible enriching experience. The instructors were very supportive.
                                Thank you for such a valuable learning opportunity for the kids.
                                Lorem ipsum neccesioutos nihil perspective repellate? isit
                            </p>
                         </div>
                    </div>
                </div>
            </div>
          </div>

          <div className='slides'>
            <div className='slideshow'>
                <div className='sliding1'>
                    <img className='img1' src={person3} alt='' />
                    <div>
                        <p className='img_title'>TRAINEE</p>
                        <h3 className='img_name'>Samar</h3>
                        <p className='img_des'>Student</p>
                    </div>
                </div>
                <div className='sliding2'>
                    <img className='img2' src={quote} alt='' />
                    <div className='img2_body'>
                         <div className='testi'>
                            <div>
                                <h3 className='img2_parent'>Parent Samar</h3>
                                <p className='img2_comments'>Let's see what Samar parents said about us</p>
                            </div>

                            <div className='rating'>
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                                <RiStarFill />
                            </div>
                         </div>

                         <div>
                            <p className='img2_content'>This course was incredible enriching experience. The instructors were very supportive.
                                Thank you for such a valuable learning opportunity for the kids.
                                Lorem ipsum neccesioutos nihil perspective repellate? isit
                            </p>
                         </div>
                    </div>
                </div>
            </div>
          </div>
        </Slider>
      </div>
    </section>
  )
}

export default Testimonial
